// JavaScript Document
$(document).ready(function(){
	$('.col-sm-2').hover(function(){
		$(this).animate({width:'90%'});
	});
});